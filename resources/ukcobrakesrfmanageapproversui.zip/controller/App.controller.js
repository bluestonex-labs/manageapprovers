sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("uk.co.brakes.rf.manageapproversui.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map